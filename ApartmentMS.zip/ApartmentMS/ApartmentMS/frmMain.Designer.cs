﻿partial class frmMain
{
    #region Windows Form Designer generated code

    private void InitializeComponent()
    {
        this.menuStrip1 = new System.Windows.Forms.MenuStrip();
        this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.printToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.addToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.apartmentToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
        this.ownerToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
        this.deleteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.apartmentToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
        this.ownerToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
        this.sortByToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.ownerToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
        this.apartmentToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
        this.apartmentSizeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.residentsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.paymerntDateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.leaseDateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.lstData = new System.Windows.Forms.ListBox();
        this.listBox1 = new System.Windows.Forms.ListBox();
        this.editToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
        this.apartmentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.ownerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.label1 = new System.Windows.Forms.Label();
        this.label2 = new System.Windows.Forms.Label();
        this.bothToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.ownersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.apartmentsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.menuStrip1.SuspendLayout();
        this.SuspendLayout();
        // 
        // menuStrip1
        // 
        this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.editToolStripMenuItem,
            this.sortByToolStripMenuItem});
        this.menuStrip1.Location = new System.Drawing.Point(0, 0);
        this.menuStrip1.Name = "menuStrip1";
        this.menuStrip1.Size = new System.Drawing.Size(1065, 24);
        this.menuStrip1.TabIndex = 2;
        this.menuStrip1.Text = "menuStrip1";
        // 
        // fileToolStripMenuItem
        // 
        this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openToolStripMenuItem,
            this.exitToolStripMenuItem,
            this.printToolStripMenuItem});
        this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
        this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
        this.fileToolStripMenuItem.Text = "File";
        // 
        // openToolStripMenuItem
        // 
        this.openToolStripMenuItem.Name = "openToolStripMenuItem";
        this.openToolStripMenuItem.Size = new System.Drawing.Size(103, 22);
        this.openToolStripMenuItem.Text = "Open";
        this.openToolStripMenuItem.Click += new System.EventHandler(this.openToolStripMenuItem_Click);
        // 
        // exitToolStripMenuItem
        // 
        this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
        this.exitToolStripMenuItem.Size = new System.Drawing.Size(103, 22);
        this.exitToolStripMenuItem.Text = "Exit";
        this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
        // 
        // printToolStripMenuItem
        // 
        this.printToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bothToolStripMenuItem,
            this.ownersToolStripMenuItem,
            this.apartmentsToolStripMenuItem});
        this.printToolStripMenuItem.Name = "printToolStripMenuItem";
        this.printToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
        this.printToolStripMenuItem.Text = "Print";
        // 
        // editToolStripMenuItem
        // 
        this.editToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addToolStripMenuItem,
            this.deleteToolStripMenuItem,
            this.editToolStripMenuItem1});
        this.editToolStripMenuItem.Name = "editToolStripMenuItem";
        this.editToolStripMenuItem.Size = new System.Drawing.Size(39, 20);
        this.editToolStripMenuItem.Text = "Edit";
        // 
        // addToolStripMenuItem
        // 
        this.addToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.apartmentToolStripMenuItem2,
            this.ownerToolStripMenuItem2});
        this.addToolStripMenuItem.Name = "addToolStripMenuItem";
        this.addToolStripMenuItem.Size = new System.Drawing.Size(131, 22);
        this.addToolStripMenuItem.Text = "Add";
        // 
        // apartmentToolStripMenuItem2
        // 
        this.apartmentToolStripMenuItem2.Name = "apartmentToolStripMenuItem2";
        this.apartmentToolStripMenuItem2.Size = new System.Drawing.Size(131, 22);
        this.apartmentToolStripMenuItem2.Text = "Apartment";
        // 
        // ownerToolStripMenuItem2
        // 
        this.ownerToolStripMenuItem2.Name = "ownerToolStripMenuItem2";
        this.ownerToolStripMenuItem2.Size = new System.Drawing.Size(131, 22);
        this.ownerToolStripMenuItem2.Text = "Owner";
        // 
        // deleteToolStripMenuItem
        // 
        this.deleteToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.apartmentToolStripMenuItem3,
            this.ownerToolStripMenuItem3});
        this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
        this.deleteToolStripMenuItem.Size = new System.Drawing.Size(131, 22);
        this.deleteToolStripMenuItem.Text = "Delete";
        // 
        // apartmentToolStripMenuItem3
        // 
        this.apartmentToolStripMenuItem3.Name = "apartmentToolStripMenuItem3";
        this.apartmentToolStripMenuItem3.Size = new System.Drawing.Size(131, 22);
        this.apartmentToolStripMenuItem3.Text = "Apartment";
        // 
        // ownerToolStripMenuItem3
        // 
        this.ownerToolStripMenuItem3.Name = "ownerToolStripMenuItem3";
        this.ownerToolStripMenuItem3.Size = new System.Drawing.Size(131, 22);
        this.ownerToolStripMenuItem3.Text = "Owner";
        // 
        // sortByToolStripMenuItem
        // 
        this.sortByToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ownerToolStripMenuItem1,
            this.apartmentToolStripMenuItem1,
            this.apartmentSizeToolStripMenuItem,
            this.residentsToolStripMenuItem,
            this.paymerntDateToolStripMenuItem,
            this.leaseDateToolStripMenuItem});
        this.sortByToolStripMenuItem.Name = "sortByToolStripMenuItem";
        this.sortByToolStripMenuItem.Size = new System.Drawing.Size(56, 20);
        this.sortByToolStripMenuItem.Text = "Sort By";
        // 
        // ownerToolStripMenuItem1
        // 
        this.ownerToolStripMenuItem1.Name = "ownerToolStripMenuItem1";
        this.ownerToolStripMenuItem1.Size = new System.Drawing.Size(154, 22);
        this.ownerToolStripMenuItem1.Text = "Leaser";
        // 
        // apartmentToolStripMenuItem1
        // 
        this.apartmentToolStripMenuItem1.Name = "apartmentToolStripMenuItem1";
        this.apartmentToolStripMenuItem1.Size = new System.Drawing.Size(154, 22);
        this.apartmentToolStripMenuItem1.Text = "Apartment #";
        // 
        // apartmentSizeToolStripMenuItem
        // 
        this.apartmentSizeToolStripMenuItem.Name = "apartmentSizeToolStripMenuItem";
        this.apartmentSizeToolStripMenuItem.Size = new System.Drawing.Size(154, 22);
        this.apartmentSizeToolStripMenuItem.Text = "Apartment Size";
        // 
        // residentsToolStripMenuItem
        // 
        this.residentsToolStripMenuItem.Name = "residentsToolStripMenuItem";
        this.residentsToolStripMenuItem.Size = new System.Drawing.Size(154, 22);
        this.residentsToolStripMenuItem.Text = "Resident #s";
        // 
        // paymerntDateToolStripMenuItem
        // 
        this.paymerntDateToolStripMenuItem.Name = "paymerntDateToolStripMenuItem";
        this.paymerntDateToolStripMenuItem.Size = new System.Drawing.Size(154, 22);
        this.paymerntDateToolStripMenuItem.Text = "Paymernt Date";
        // 
        // leaseDateToolStripMenuItem
        // 
        this.leaseDateToolStripMenuItem.Name = "leaseDateToolStripMenuItem";
        this.leaseDateToolStripMenuItem.Size = new System.Drawing.Size(154, 22);
        this.leaseDateToolStripMenuItem.Text = "Lease Date";
        // 
        // lstData
        // 
        this.lstData.FormattingEnabled = true;
        this.lstData.Location = new System.Drawing.Point(12, 62);
        this.lstData.Name = "lstData";
        this.lstData.Size = new System.Drawing.Size(1041, 238);
        this.lstData.TabIndex = 3;
        // 
        // listBox1
        // 
        this.listBox1.FormattingEnabled = true;
        this.listBox1.Location = new System.Drawing.Point(12, 362);
        this.listBox1.Name = "listBox1";
        this.listBox1.Size = new System.Drawing.Size(1041, 316);
        this.listBox1.TabIndex = 4;
        // 
        // editToolStripMenuItem1
        // 
        this.editToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.apartmentToolStripMenuItem,
            this.ownerToolStripMenuItem});
        this.editToolStripMenuItem1.Name = "editToolStripMenuItem1";
        this.editToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
        this.editToolStripMenuItem1.Text = "Edit";
        // 
        // apartmentToolStripMenuItem
        // 
        this.apartmentToolStripMenuItem.Name = "apartmentToolStripMenuItem";
        this.apartmentToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
        this.apartmentToolStripMenuItem.Text = "Apartment";
        // 
        // ownerToolStripMenuItem
        // 
        this.ownerToolStripMenuItem.Name = "ownerToolStripMenuItem";
        this.ownerToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
        this.ownerToolStripMenuItem.Text = "Owner";
        // 
        // label1
        // 
        this.label1.AutoSize = true;
        this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        this.label1.Location = new System.Drawing.Point(7, 30);
        this.label1.Name = "label1";
        this.label1.Size = new System.Drawing.Size(144, 29);
        this.label1.TabIndex = 5;
        this.label1.Text = "Apartments";
        // 
        // label2
        // 
        this.label2.AutoSize = true;
        this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        this.label2.Location = new System.Drawing.Point(12, 330);
        this.label2.Name = "label2";
        this.label2.Size = new System.Drawing.Size(106, 29);
        this.label2.TabIndex = 6;
        this.label2.Text = "Leasers";
        // 
        // bothToolStripMenuItem
        // 
        this.bothToolStripMenuItem.Name = "bothToolStripMenuItem";
        this.bothToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
        this.bothToolStripMenuItem.Text = "Both";
        // 
        // ownersToolStripMenuItem
        // 
        this.ownersToolStripMenuItem.Name = "ownersToolStripMenuItem";
        this.ownersToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
        this.ownersToolStripMenuItem.Text = "Owners";
        // 
        // apartmentsToolStripMenuItem
        // 
        this.apartmentsToolStripMenuItem.Name = "apartmentsToolStripMenuItem";
        this.apartmentsToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
        this.apartmentsToolStripMenuItem.Text = "Apartments";
        // 
        // frmMain
        // 
        this.ClientSize = new System.Drawing.Size(1065, 687);
        this.Controls.Add(this.label2);
        this.Controls.Add(this.label1);
        this.Controls.Add(this.listBox1);
        this.Controls.Add(this.lstData);
        this.Controls.Add(this.menuStrip1);
        this.MainMenuStrip = this.menuStrip1;
        this.Name = "frmMain";
        this.Text = "Apartment Management ";
        this.menuStrip1.ResumeLayout(false);
        this.menuStrip1.PerformLayout();
        this.ResumeLayout(false);
        this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.MenuStrip menuStrip1;
    private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
    private System.Windows.Forms.ListBox lstData;
    private System.Windows.Forms.ToolStripMenuItem printToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem addToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem apartmentToolStripMenuItem2;
    private System.Windows.Forms.ToolStripMenuItem ownerToolStripMenuItem2;
    private System.Windows.Forms.ToolStripMenuItem deleteToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem apartmentToolStripMenuItem3;
    private System.Windows.Forms.ToolStripMenuItem ownerToolStripMenuItem3;
    private System.Windows.Forms.ToolStripMenuItem sortByToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem ownerToolStripMenuItem1;
    private System.Windows.Forms.ToolStripMenuItem apartmentToolStripMenuItem1;
    private System.Windows.Forms.ToolStripMenuItem apartmentSizeToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem residentsToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem paymerntDateToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem leaseDateToolStripMenuItem;
    private System.Windows.Forms.ListBox listBox1;
    private System.Windows.Forms.ToolStripMenuItem bothToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem ownersToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem apartmentsToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem1;
    private System.Windows.Forms.ToolStripMenuItem apartmentToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem ownerToolStripMenuItem;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.Label label2;
}